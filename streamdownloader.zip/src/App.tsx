import React, { useState, useEffect } from 'react';
import { 
  Download, 
  Settings, 
  Video, 
  HelpCircle, 
  Key, 
  Server, 
  ShieldAlert, 
  X, 
  RefreshCw, 
  CheckCircle2, 
  ExternalLink, 
  Sparkles, 
  Play, 
  AlertTriangle,
  ChevronRight,
  Info
} from 'lucide-react';

interface Job {
  id: string;
  url: string;
  type: string;
  status: 'pending' | 'parsing' | 'downloading' | 'merging' | 'completed' | 'failed';
  progress: number;
  downloadedSegments: number;
  totalSegments: number;
  speed: string;
  filename: string;
  error?: string;
}

interface Segment {
  url: string;
  index: number;
  status: 'pending' | 'downloading' | 'completed' | 'failed';
}

interface JobDetail extends Job {
  segments: Segment[];
  customHeaders?: Record<string, string>;
  decryptionKey?: string;
  decryptionIv?: string;
}

interface Variant {
  resolution: string;
  bandwidth: number;
  url: string;
}

export default function App() {
  // Input fields
  const [streamUrl, setStreamUrl] = useState('');
  const [customHeadersRaw, setCustomHeadersRaw] = useState('');
  const [decryptionKey, setDecryptionKey] = useState('');
  const [decryptionIv, setDecryptionIv] = useState('');
  const [filename, setFilename] = useState('');

  // UI state
  const [activeTab, setActiveTab] = useState<'downloader' | 'advanced' | 'about'>('downloader');
  const [jobs, setJobs] = useState<Job[]>([]);
  const [selectedJob, setSelectedJob] = useState<JobDetail | null>(null);
  const [isLoadingParse, setIsLoadingParse] = useState(false);
  const [parseResult, setParseResult] = useState<{
    type: string;
    variants?: Variant[];
    totalSegments?: number;
    encryption?: { method: string; url: string; iv?: string } | null;
    extractedStreams?: { url: string; type: 'm3u8' | 'mpd' | 'mp4'; label: string }[];
  } | null>(null);
  const [selectedVariant, setSelectedVariant] = useState<Variant | null>(null);
  const [notification, setNotification] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  // Poll for jobs periodically
  useEffect(() => {
    fetchJobs();
    const interval = setInterval(fetchJobs, 1000);
    return () => clearInterval(interval);
  }, []);

  // Poll for selected job details if downloading or merging
  useEffect(() => {
    if (!selectedJob) return;
    const isOngoing = ['pending', 'parsing', 'downloading', 'merging'].includes(selectedJob.status);
    if (!isOngoing) return;

    const interval = setInterval(async () => {
      try {
        const res = await fetch(`/api/status/${selectedJob.id}`);
        if (res.ok) {
          const data = await res.json();
          setSelectedJob(data);
        }
      } catch (err) {
        console.error('Failed to fetch job detail:', err);
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [selectedJob?.id, selectedJob?.status]);

  const showNotification = (type: 'success' | 'error', message: string) => {
    setNotification({ type, message });
    setTimeout(() => setNotification(null), 5000);
  };

  const fetchJobs = async () => {
    try {
      const res = await fetch('/api/jobs');
      if (res.ok) {
        const data = await res.json();
        setJobs(data);
      }
    } catch (err) {
      console.error('Failed to fetch jobs:', err);
    }
  };

  const handleParseStream = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!streamUrl) {
      showNotification('error', 'Please enter a stream URL');
      return;
    }

    setIsLoadingParse(true);
    setParseResult(null);
    setSelectedVariant(null);

    let parsedHeaders: Record<string, string> = {};
    if (customHeadersRaw.trim()) {
      try {
        // Support JSON or flat Key:Value representation
        if (customHeadersRaw.trim().startsWith('{')) {
          parsedHeaders = JSON.parse(customHeadersRaw);
        } else {
          customHeadersRaw.split('\n').forEach(line => {
            const idx = line.indexOf(':');
            if (idx > -1) {
              const k = line.substring(0, idx).trim();
              const v = line.substring(idx + 1).trim();
              if (k && v) parsedHeaders[k] = v;
            }
          });
        }
      } catch (err) {
        showNotification('error', 'Headers must be valid key:value lines or JSON');
        setIsLoadingParse(false);
        return;
      }
    }

    try {
      const res = await fetch('/api/parse', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: streamUrl, headers: parsedHeaders }),
      });

      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData.error || 'Parsing failed');
      }

      const data = await res.json();
      setParseResult(data);
      if (data.variants && data.variants.length > 0) {
        // Default to highest bandwidth/quality variant
        const best = data.variants.reduce((prev: Variant, curr: Variant) => curr.bandwidth > prev.bandwidth ? curr : prev, data.variants[0]);
        setSelectedVariant(best);
      }
      showNotification('success', `Stream parsed successfully as ${data.type}`);
    } catch (err: any) {
      showNotification('error', `Parse Error: ${err.message}`);
    } finally {
      setIsLoadingParse(false);
    }
  };

  const triggerDownload = async () => {
    let parsedHeaders: Record<string, string> = {};
    if (customHeadersRaw.trim()) {
      try {
        if (customHeadersRaw.trim().startsWith('{')) {
          parsedHeaders = JSON.parse(customHeadersRaw);
        } else {
          customHeadersRaw.split('\n').forEach(line => {
            const idx = line.indexOf(':');
            if (idx > -1) {
              const k = line.substring(0, idx).trim();
              const v = line.substring(idx + 1).trim();
              if (k && v) parsedHeaders[k] = v;
            }
          });
        }
      } catch (err) {
        showNotification('error', 'Failed to parse custom headers.');
        return;
      }
    }

    // Determine type
    let finalType = 'm3u8';
    if (parseResult?.type === 'mp4' || streamUrl.includes('.mp4')) {
      finalType = 'mp4';
    } else if (parseResult?.type === 'mpd' || streamUrl.includes('.mpd')) {
      finalType = 'mpd';
    }

    try {
      const res = await fetch('/api/download', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          url: streamUrl,
          type: finalType,
          selectedVariantUrl: selectedVariant?.url || null,
          headers: parsedHeaders,
          decryptionKey: decryptionKey || null,
          decryptionIv: decryptionIv || null,
          filename: filename || null,
        }),
      });

      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData.error || 'Failed to trigger download');
      }

      const data = await res.json();
      showNotification('success', 'Download task added successfully!');
      
      // Auto open detailed status of the newly created job
      const jobRes = await fetch(`/api/status/${data.jobId}`);
      if (jobRes.ok) {
        const jobDetail = await jobRes.json();
        setSelectedJob(jobDetail);
      }

      // Reset parsing state
      setParseResult(null);
    } catch (err: any) {
      showNotification('error', `Download error: ${err.message}`);
    }
  };

  const handleCancel = async (jobId: string) => {
    try {
      const res = await fetch(`/api/cancel/${jobId}`, { method: 'POST' });
      if (res.ok) {
        showNotification('success', 'Download task cancelled.');
        fetchJobs();
        if (selectedJob?.id === jobId) {
          setSelectedJob(null);
        }
      }
    } catch (err) {
      showNotification('error', 'Failed to cancel download task.');
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      {/* Top Header / Brand */}
      <header className="border-b border-slate-800 bg-slate-900/60 backdrop-blur-md sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-gradient-to-tr from-indigo-600 to-violet-500 p-2.5 rounded-xl shadow-lg shadow-indigo-500/20">
              <Download className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="font-bold text-lg tracking-tight bg-gradient-to-r from-white via-slate-100 to-indigo-300 bg-clip-text text-transparent">
                LJ StreamDownloader
              </h1>
              <p className="text-xs text-slate-400">Stream Downloader Engine & Decryption Analyzer</p>
            </div>
          </div>

          <div className="flex gap-1.5 bg-slate-950 p-1.5 rounded-xl border border-slate-800">
            <button
              onClick={() => setActiveTab('downloader')}
              className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-all duration-200 ${
                activeTab === 'downloader'
                  ? 'bg-indigo-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Downloader
            </button>
            <button
              onClick={() => setActiveTab('advanced')}
              className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-all duration-200 ${
                activeTab === 'advanced'
                  ? 'bg-indigo-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Key Settings
            </button>
            <button
              onClick={() => setActiveTab('about')}
              className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-all duration-200 ${
                activeTab === 'about'
                  ? 'bg-indigo-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              How It Works
            </button>
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8 flex flex-col gap-6">
        {/* Notifications */}
        {notification && (
          <div
            className={`fixed bottom-6 right-6 z-50 flex items-center gap-3 px-4 py-3 rounded-xl border shadow-xl animate-bounce ${
              notification.type === 'success'
                ? 'bg-emerald-950/90 border-emerald-500/30 text-emerald-300'
                : 'bg-rose-950/90 border-rose-500/30 text-rose-300'
            }`}
          >
            <Info className="w-4 h-4" />
            <span className="text-xs font-medium">{notification.message}</span>
          </div>
        )}

        {activeTab === 'downloader' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            
            {/* Left Column: Parsers and Download controllers */}
            <div className="lg:col-span-7 flex flex-col gap-6">
              
              {/* Main Input Form */}
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-sm">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2">
                    <Video className="w-4 h-4 text-indigo-400" />
                    <h2 className="font-semibold text-sm">Download Stream URL</h2>
                  </div>
                  <span className="text-[10px] bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 px-2 py-0.5 rounded-full font-semibold">
                    m3u8, mpd, mp4
                  </span>
                </div>

                <form onSubmit={handleParseStream} className="flex flex-col gap-4">
                  <div>
                    <label className="block text-xs font-medium text-slate-400 mb-1.5">Stream Playlist or File URL</label>
                    <input
                      type="url"
                      required
                      placeholder="https://example.com/playlist.m3u8 or video.mpd"
                      value={streamUrl}
                      onChange={(e) => setStreamUrl(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-600 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-colors"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-medium text-slate-400 mb-1.5">Output Filename (Optional)</label>
                      <input
                        type="text"
                        placeholder="movie_stream.mp4"
                        value={filename}
                        onChange={(e) => setFilename(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-600 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-colors"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-slate-400 mb-1.5">Custom Headers / Cookies (Optional)</label>
                      <textarea
                        rows={1}
                        placeholder="User-Agent: SpecialUA&#10;Cookie: auth=xyz"
                        value={customHeadersRaw}
                        onChange={(e) => setCustomHeadersRaw(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-600 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-colors resize-none"
                      />
                    </div>
                  </div>

                  <div className="flex justify-end pt-2">
                    <button
                      type="submit"
                      disabled={isLoadingParse}
                      className="bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs px-5 py-2.5 rounded-xl flex items-center gap-2 transition-all shadow-lg shadow-indigo-600/15 disabled:opacity-50"
                    >
                      {isLoadingParse ? (
                        <>
                          <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                          Analyzing Stream Manifest...
                        </>
                      ) : (
                        <>
                          <Play className="w-3.5 h-3.5" />
                          Analyze & Parse Stream
                        </>
                      )}
                    </button>
                  </div>
                </form>
              </div>

              {/* Parsing Stream Results / Stream Variant Picker */}
              {parseResult && (
                <div className="bg-indigo-950/20 border border-indigo-500/20 rounded-2xl p-5 sm:p-6">
                  <div className="flex items-center gap-2 mb-4 text-indigo-300">
                    <Sparkles className="w-4 h-4" />
                    <h3 className="font-semibold text-sm">Analyzed Stream Details</h3>
                  </div>

                  <div className="flex flex-col gap-4 text-xs">
                    {parseResult.type === 'extracted-webpage' && parseResult.extractedStreams && parseResult.extractedStreams.length > 0 ? (
                      <div className="flex flex-col gap-3">
                        <div className="p-3 bg-amber-500/10 border border-amber-500/20 rounded-xl text-amber-200">
                          <span className="font-bold flex items-center gap-1 mb-1">
                            <Sparkles className="w-4 h-4 text-amber-400" />
                            Auto-Scraper Extracted Stream Links Found!
                          </span>
                          <p className="text-[11px] leading-relaxed opacity-90">
                            We crawled the target webpage and successfully discovered active stream segments without needing developer tools. Select a stream below to load and configure it automatically:
                          </p>
                        </div>
                        <div className="flex flex-col gap-2 max-h-72 overflow-y-auto pr-1">
                          {parseResult.extractedStreams.map((stream, idx) => (
                            <div 
                              key={idx}
                              className="bg-slate-900 border border-slate-800 rounded-xl p-3.5 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 hover:border-slate-700 transition-colors"
                            >
                              <div className="flex-1 min-w-0 text-left">
                                <span className="text-[9px] bg-indigo-500/20 text-indigo-300 px-2 py-0.5 rounded font-bold uppercase">
                                  {stream.type}
                                </span>
                                <span className="ml-2 font-bold text-slate-200 text-xs">{stream.label}</span>
                                <p className="text-[10px] text-slate-500 truncate font-mono mt-1 break-all select-all">{stream.url}</p>
                              </div>
                              <button
                                onClick={async () => {
                                  setStreamUrl(stream.url);
                                  setIsLoadingParse(true);
                                  setParseResult(null);
                                  try {
                                    const res = await fetch('/api/parse', {
                                      method: 'POST',
                                      headers: { 'Content-Type': 'application/json' },
                                      body: JSON.stringify({ url: stream.url }),
                                    });
                                    if (res.ok) {
                                      const data = await res.json();
                                      setParseResult(data);
                                      if (data.variants && data.variants.length > 0) {
                                        const best = data.variants.reduce((prev: Variant, curr: Variant) => curr.bandwidth > prev.bandwidth ? curr : prev, data.variants[0]);
                                        setSelectedVariant(best);
                                      }
                                      showNotification('success', `Selected stream loaded successfully!`);
                                    } else {
                                      const errData = await res.json();
                                      throw new Error(errData.error || 'Failed to parse stream');
                                    }
                                  } catch (err: any) {
                                    showNotification('error', err.message);
                                  } finally {
                                    setIsLoadingParse(false);
                                  }
                                }}
                                className="bg-indigo-600 hover:bg-indigo-500 text-white text-[11px] font-bold px-3 py-2 rounded-lg self-end sm:self-auto transition-colors flex items-center gap-1 shrink-0"
                              >
                                Select & Load
                                <ChevronRight className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          ))}
                        </div>
                      </div>
                    ) : (
                      <>
                        <div className="grid grid-cols-2 gap-4 border-b border-indigo-500/10 pb-4">
                          <div>
                            <span className="text-slate-400 block mb-0.5">Detected Stream Type</span>
                            <span className="font-bold text-indigo-400 uppercase">{parseResult.type}</span>
                          </div>
                          <div>
                            <span className="text-slate-400 block mb-0.5">Encryption Shield</span>
                            {parseResult.encryption ? (
                              <span className="font-semibold text-amber-400 flex items-center gap-1">
                                <AlertTriangle className="w-3.5 h-3.5 text-amber-500" />
                                {parseResult.encryption.method} Standard
                              </span>
                            ) : (
                              <span className="font-semibold text-emerald-400">None detected / Open</span>
                            )}
                          </div>
                        </div>

                        {/* Quality Multi-Variant selector for M3U8/MPD playlists */}
                        {parseResult.variants && parseResult.variants.length > 0 && (
                          <div>
                            <label className="block text-slate-400 font-medium mb-2">Available Qualities / Variants</label>
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-48 overflow-y-auto pr-1">
                              {parseResult.variants.map((v, i) => (
                                <button
                                  key={i}
                                  onClick={() => setSelectedVariant(v)}
                                  className={`p-3 rounded-xl border text-left flex flex-col gap-1 transition-all ${
                                    selectedVariant?.bandwidth === v.bandwidth
                                      ? 'bg-indigo-600/20 border-indigo-500 text-indigo-200'
                                      : 'bg-slate-900 border-slate-800 hover:border-slate-700'
                                  }`}
                                >
                                  <span className="font-bold">{v.resolution}</span>
                                  <span className="text-[10px] text-slate-400">Bandwidth: {(v.bandwidth / 1000).toFixed(0)} kbps</span>
                                </button>
                              ))}
                            </div>
                          </div>
                        )}

                        {parseResult.totalSegments && (
                          <div className="bg-slate-900/60 p-3.5 rounded-xl border border-slate-800 flex items-center justify-between">
                            <div>
                              <span className="text-slate-400">Segment Count</span>
                              <span className="font-bold text-white block mt-0.5">{parseResult.totalSegments} video parts</span>
                            </div>
                            <div className="text-right">
                              <span className="text-slate-400">Est. Combined Size</span>
                              <span className="font-bold text-slate-200 block mt-0.5">
                                {(parseResult.totalSegments * 0.95).toFixed(1)} MB
                              </span>
                            </div>
                          </div>
                        )}

                        <div className="flex items-center justify-between pt-2 border-t border-indigo-500/10">
                          <div className="flex items-center gap-1.5 text-slate-400">
                            <Info className="w-3.5 h-3.5 text-slate-500" />
                            <span>Ready to build & download.</span>
                          </div>
                          <button
                            onClick={triggerDownload}
                            className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs px-5 py-2.5 rounded-xl flex items-center gap-1.5 transition-all shadow-md shadow-emerald-600/10"
                          >
                            <Download className="w-3.5 h-3.5" />
                            Download Now
                          </button>
                        </div>
                      </>
                    )}
                  </div>
                </div>
              )}

              {/* Active / Historical Downloads list */}
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2">
                    <Server className="w-4 h-4 text-indigo-400" />
                    <h3 className="font-semibold text-sm">Download Monitor & Queue</h3>
                  </div>
                  <span className="text-[10px] bg-slate-800 text-slate-400 px-2 py-0.5 rounded-full">
                    {jobs.length} tasks
                  </span>
                </div>

                {jobs.length === 0 ? (
                  <div className="py-8 flex flex-col items-center justify-center text-slate-500 text-xs border border-dashed border-slate-800 rounded-xl">
                    <Video className="w-8 h-8 mb-2 text-slate-700" />
                    <p>No active download jobs in queue.</p>
                    <p className="text-[10px] text-slate-600 mt-0.5">Enter a stream playlist above to get started.</p>
                  </div>
                ) : (
                  <div className="flex flex-col gap-3">
                    {jobs.map((job) => {
                      const isActive = ['downloading', 'merging', 'pending'].includes(job.status);
                      return (
                        <div
                          key={job.id}
                          className={`p-4 rounded-xl border transition-all ${
                            selectedJob?.id === job.id
                              ? 'bg-indigo-950/10 border-indigo-500/40'
                              : 'bg-slate-950 border-slate-800 hover:border-slate-700'
                          }`}
                        >
                          <div className="flex items-start justify-between gap-4 mb-2">
                            <div className="cursor-pointer" onClick={async () => {
                              const res = await fetch(`/api/status/${job.id}`);
                              if (res.ok) setSelectedJob(await res.json());
                            }}>
                              <span className="text-[10px] font-semibold text-slate-500 font-mono block">ID: {job.id}</span>
                              <span className="font-medium text-xs text-white line-clamp-1 mt-0.5">{job.filename}</span>
                              <span className="text-[10px] text-slate-400 line-clamp-1 font-mono mt-0.5">{job.url}</span>
                            </div>

                            <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded ${
                              job.status === 'completed' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' :
                              job.status === 'failed' ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20' :
                              job.status === 'merging' ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20' :
                              'bg-indigo-500/10 text-indigo-400 border border-indigo-500/20'
                            }`}>
                              {job.status}
                            </span>
                          </div>

                          {/* Progress Line */}
                          <div className="w-full bg-slate-900 rounded-full h-1.5 overflow-hidden mb-3">
                            <div
                              className={`h-full transition-all duration-300 ${
                                job.status === 'completed' ? 'bg-emerald-500' :
                                job.status === 'failed' ? 'bg-rose-500' : 'bg-indigo-500'
                              }`}
                              style={{ width: `${job.progress}%` }}
                            />
                          </div>

                          <div className="flex items-center justify-between text-[10px] text-slate-400">
                            <div className="flex items-center gap-3">
                              <span>{job.progress}% progress</span>
                              {isActive && (
                                <>
                                  <span className="w-1 h-1 rounded-full bg-slate-700" />
                                  <span className="text-slate-300 font-mono">{job.speed}</span>
                                </>
                              )}
                              {job.totalSegments > 0 && (
                                <>
                                  <span className="w-1 h-1 rounded-full bg-slate-700" />
                                  <span>{job.downloadedSegments} / {job.totalSegments} parts</span>
                                </>
                              )}
                            </div>

                            <div className="flex items-center gap-2">
                              {job.status === 'completed' && (
                                <a
                                  href={`/api/download-file/${job.id}`}
                                  className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-2.5 py-1 rounded text-[10px] transition-all flex items-center gap-1"
                                >
                                  Download MP4
                                  <ExternalLink className="w-3 h-3" />
                                </a>
                              )}
                              {isActive && (
                                <button
                                  onClick={() => handleCancel(job.id)}
                                  className="text-slate-500 hover:text-rose-400 p-1 transition-colors"
                                  title="Cancel Download"
                                >
                                  <X className="w-3.5 h-3.5" />
                                </button>
                              )}
                            </div>
                          </div>

                          {job.error && (
                            <p className="text-[10px] text-rose-400 bg-rose-500/5 border border-rose-500/10 p-2 rounded-lg mt-3">
                              {job.error}
                            </p>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

            </div>

            {/* Right Column: Detailed Visualizer for the selected/active download task */}
            <div className="lg:col-span-5 flex flex-col gap-6">
              
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 sticky top-24">
                <div className="flex items-center justify-between mb-4 pb-4 border-b border-slate-800">
                  <div className="flex items-center gap-2">
                    <Settings className="w-4 h-4 text-indigo-400" />
                    <h3 className="font-semibold text-sm">Download Stream Analyzer</h3>
                  </div>
                  {selectedJob && (
                    <button
                      onClick={() => setSelectedJob(null)}
                      className="text-slate-400 hover:text-white"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  )}
                </div>

                {!selectedJob ? (
                  <div className="py-12 flex flex-col items-center justify-center text-slate-500 text-xs text-center px-4">
                    <ShieldAlert className="w-10 h-10 mb-2.5 text-slate-700" />
                    <h4 className="font-medium text-slate-400 mb-1">No Active Stream Selected</h4>
                    <p className="text-[10px] text-slate-600 max-w-xs">
                      Analyze a stream, hit download, and select a task to monitor real-time video segment chunks download and merging progress.
                    </p>
                  </div>
                ) : (
                  <div className="flex flex-col gap-4">
                    <div className="flex flex-col gap-1.5">
                      <span className="text-[9px] font-semibold text-slate-500 tracking-wider uppercase">Analyses For Target</span>
                      <h4 className="font-bold text-xs text-white line-clamp-1">{selectedJob.filename}</h4>
                      <div className="text-[10px] bg-slate-950 p-2.5 rounded-lg border border-slate-800 font-mono text-slate-400 break-all select-all">
                        {selectedJob.url}
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3 mt-1">
                      <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                        <span className="text-[10px] text-slate-500 block">Downloader Type</span>
                        <span className="font-bold text-xs uppercase text-indigo-400">{selectedJob.type}</span>
                      </div>
                      <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                        <span className="text-[10px] text-slate-500 block">Merged Format</span>
                        <span className="font-bold text-xs text-emerald-400">MP4 (MPEG-4)</span>
                      </div>
                    </div>

                    {/* Encryption & Decryption Engine Analysis details */}
                    <div className="bg-indigo-950/15 border border-indigo-500/10 rounded-xl p-4 flex flex-col gap-2">
                      <div className="flex items-center gap-1.5 text-indigo-300 font-semibold text-xs">
                        <Key className="w-3.5 h-3.5 text-indigo-400" />
                        Decryption Cryptography Engine
                      </div>
                      <div className="text-[11px] text-slate-400 leading-relaxed">
                        {selectedJob.decryptionKey ? (
                          <div className="flex flex-col gap-1.5 mt-1">
                            <div className="flex items-center justify-between">
                              <span className="text-amber-400 font-bold">AES-128 DECRYPTION ON</span>
                              <span className="bg-amber-500/10 text-amber-400 border border-amber-500/20 text-[8px] px-1.5 py-0.5 rounded font-mono">
                                active
                              </span>
                            </div>
                            <div className="font-mono text-[10px] text-slate-300 bg-slate-950 p-1.5 rounded border border-slate-800 break-all">
                              <span className="text-slate-500 mr-1">KEY:</span>
                              {selectedJob.decryptionKey}
                            </div>
                            {selectedJob.decryptionIv && (
                              <div className="font-mono text-[10px] text-slate-300 bg-slate-950 p-1.5 rounded border border-slate-800 break-all">
                                <span className="text-slate-500 mr-1">IV:</span>
                                {selectedJob.decryptionIv}
                              </div>
                            )}
                          </div>
                        ) : (
                          <p>
                            This stream is using clear keys or has no segment level AES encryption. The chunks are parsed and downloaded directly.
                          </p>
                        )}
                      </div>
                    </div>

                    {/* Chunk Download Progress Visualization Grid */}
                    {selectedJob.segments && selectedJob.segments.length > 0 && (
                      <div className="mt-2">
                        <div className="flex items-center justify-between text-xs mb-2">
                          <span className="text-slate-400">Chunk Grid View</span>
                          <span className="text-slate-500 text-[10px]">{selectedJob.segments.length} total segments</span>
                        </div>

                        {/* Adaptive visualizer grid */}
                        <div className="grid grid-cols-10 gap-1 bg-slate-950 p-2.5 rounded-xl border border-slate-850 max-h-56 overflow-y-auto">
                          {selectedJob.segments.map((seg, i) => (
                            <div
                              key={i}
                              className={`aspect-square rounded-sm transition-all duration-300 ${
                                seg.status === 'completed' ? 'bg-emerald-500 shadow-sm shadow-emerald-500/10' :
                                seg.status === 'downloading' ? 'bg-indigo-500 animate-pulse' :
                                seg.status === 'failed' ? 'bg-rose-500' : 'bg-slate-800'
                              }`}
                              title={`Chunk ${i + 1}: ${seg.status}`}
                            />
                          ))}
                        </div>

                        <div className="flex items-center gap-4 mt-3 text-[10px]">
                          <div className="flex items-center gap-1 text-slate-400">
                            <span className="w-2.5 h-2.5 bg-slate-800 rounded-sm" />
                            <span>Pending</span>
                          </div>
                          <div className="flex items-center gap-1 text-slate-400">
                            <span className="w-2.5 h-2.5 bg-indigo-500 rounded-sm animate-pulse" />
                            <span>Downloading</span>
                          </div>
                          <div className="flex items-center gap-1 text-slate-400">
                            <span className="w-2.5 h-2.5 bg-emerald-500 rounded-sm" />
                            <span>Completed</span>
                          </div>
                          <div className="flex items-center gap-1 text-slate-400">
                            <span className="w-2.5 h-2.5 bg-rose-500 rounded-sm" />
                            <span>Failed</span>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>

            </div>

          </div>
        )}

        {/* Tab: Custom / Advanced Settings */}
        {activeTab === 'advanced' && (
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 max-w-3xl mx-auto w-full">
            <div className="flex items-center gap-2 mb-4 pb-4 border-b border-slate-800">
              <Key className="w-5 h-5 text-indigo-400" />
              <div>
                <h3 className="font-semibold text-sm">Decryption & DRM Credentials</h3>
                <p className="text-xs text-slate-400">Manually define AES-128 and MPEG-DASH Clearkey parameters</p>
              </div>
            </div>

            <div className="flex flex-col gap-5 text-xs">
              <div className="bg-slate-950 p-4 border border-slate-800 rounded-xl leading-relaxed text-slate-400">
                <span className="font-bold text-slate-200 block mb-1">AES-128 Decryption System</span>
                Many legal m3u8 streams use AES-128 to protect media chunks. Standard LJ downloader requests the key file URL, decrypts each downloaded piece in memory, and stitches them seamlessly into a playable .mp4 file. You can override the key below.
              </div>

              <div>
                <label className="block text-slate-400 font-medium mb-1.5">Custom Decryption Key (Hex or ASCII string)</label>
                <input
                  type="text"
                  placeholder="e.g. 1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d"
                  value={decryptionKey}
                  onChange={(e) => setDecryptionKey(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-600 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-colors"
                />
              </div>

              <div>
                <label className="block text-slate-400 font-medium mb-1.5">Initialization Vector IV (Hex - Optional)</label>
                <input
                  type="text"
                  placeholder="e.g. 00000000000000000000000000000001"
                  value={decryptionIv}
                  onChange={(e) => setDecryptionIv(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-600 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-colors"
                />
              </div>

              <div className="bg-amber-500/10 border border-amber-500/20 text-amber-300 p-4 rounded-xl flex items-start gap-3">
                <AlertTriangle className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold block mb-0.5">Clearkey & Widevine Notice</span>
                  <p className="leading-relaxed">
                    Premium subscription platforms like Netflix and Disney+ Hotstar secure their streams using advanced hardware-level and software-level **Widevine DRM (Digital Rights Management)**. Widevine streams use licensed keys that cannot be extracted via clear key or basic AES-128 downloads.
                  </p>
                </div>
              </div>

              <div className="flex justify-end pt-2">
                <button
                  onClick={() => {
                    showNotification('success', 'Custom decryption criteria updated');
                    setActiveTab('downloader');
                  }}
                  className="bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs px-5 py-2.5 rounded-xl transition-all shadow-md shadow-indigo-600/10"
                >
                  Apply & Save Settings
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Tab: About / Instructions */}
        {activeTab === 'about' && (
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 max-w-3xl mx-auto w-full flex flex-col gap-6">
            <div className="pb-4 border-b border-slate-800">
              <h3 className="font-semibold text-sm flex items-center gap-2">
                <HelpCircle className="w-5 h-5 text-indigo-400" />
                How LJ Video Downloader Engine Works
              </h3>
              <p className="text-xs text-slate-400 mt-1">Discover the streaming technologies behind modern video playback and downloading</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs leading-relaxed text-slate-400">
              <div className="flex flex-col gap-3">
                <span className="font-bold text-slate-200 text-sm flex items-center gap-1.5">
                  <span className="flex items-center justify-center bg-indigo-500/15 text-indigo-400 w-5 h-5 rounded-full font-mono text-xs">1</span>
                  Stream Parsing
                </span>
                <p>
                  Videos on the web are rarely streamed as a single large file. Instead, they are sliced into hundreds of tiny individual video chunks (usually TS or m4s formats). An index file (such as `.m3u8` for HLS or `.mpd` for MPEG-DASH) guides the browser on which chunks to request.
                </p>
              </div>

              <div className="flex flex-col gap-3">
                <span className="font-bold text-slate-200 text-sm flex items-center gap-1.5">
                  <span className="flex items-center justify-center bg-indigo-500/15 text-indigo-400 w-5 h-5 rounded-full font-mono text-xs">2</span>
                  Parallel Downloader
                </span>
                <p>
                  Instead of downloading one after another, this engine utilizes multiple threads/workers to request several video chunks simultaneously, maximizing internet bandwidth and significantly reducing download wait time.
                </p>
              </div>

              <div className="flex flex-col gap-3">
                <span className="font-bold text-slate-200 text-sm flex items-center gap-1.5">
                  <span className="flex items-center justify-center bg-indigo-500/15 text-indigo-400 w-5 h-5 rounded-full font-mono text-xs">3</span>
                  AES Decryption
                </span>
                <p>
                  If a stream manifest is locked with Standard AES-128, the downloader fetches the authorization decryption key, decrypts each individual chunk on-the-fly, and outputs readable raw data.
                </p>
              </div>

              <div className="flex flex-col gap-3">
                <span className="font-bold text-slate-200 text-sm flex items-center gap-1.5">
                  <span className="flex items-center justify-center bg-indigo-500/15 text-indigo-400 w-5 h-5 rounded-full font-mono text-xs">4</span>
                  Seamless Stitching
                </span>
                <p>
                  Once all decrypted chunks are fully downloaded on the server, the system automatically stitches them back together in perfect sequence, packaging them into a single high-quality `.mp4` file ready to play or download directly to your device.
                </p>
              </div>
            </div>

            <div className="bg-slate-950 p-4 border border-slate-800 rounded-xl flex items-center gap-3">
              <Info className="w-5 h-5 text-indigo-400 shrink-0" />
              <div className="text-xs text-slate-400">
                <span className="font-bold text-slate-200 block mb-0.5">Direct Local Host Storage</span>
                All downloaded and stitched media are hosted securely in the backend server container, allowing lightning-fast local downloads without third-party redirects or ads.
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-900 bg-slate-950/80 py-6 mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <p>© 2026 LJ StreamDownloader Engine. Developed for education and stream structure analysis.</p>
          <div className="flex gap-4">
            <span className="text-[10px] font-mono">Server Status: online</span>
          </div>
        </div>
      </footer>
    </div>
  );
}

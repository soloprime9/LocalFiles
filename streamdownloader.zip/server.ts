import express from 'express';
import cors from 'cors';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import crypto from 'crypto';
import { createServer as createViteServer } from 'vite';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(cors());
app.use(express.json());

// Ensure downloads directory exists
const DOWNLOADS_DIR = path.resolve(__dirname, 'downloads');
if (!fs.existsSync(DOWNLOADS_DIR)) {
  fs.mkdirSync(DOWNLOADS_DIR, { recursive: true });
}

// Temporary directory for downloading chunks
const TEMP_DIR = path.resolve(__dirname, 'temp_chunks');
if (!fs.existsSync(TEMP_DIR)) {
  fs.mkdirSync(TEMP_DIR, { recursive: true });
}

interface Segment {
  url: string;
  index: number;
  status: 'pending' | 'downloading' | 'completed' | 'failed';
}

interface DownloadJob {
  id: string;
  url: string;
  type: 'm3u8' | 'mpd' | 'mp4';
  status: 'pending' | 'parsing' | 'downloading' | 'merging' | 'completed' | 'failed';
  progress: number;
  downloadedSegments: number;
  totalSegments: number;
  speed: string; // e.g. "1.5 MB/s"
  activeWorkers: number;
  error?: string;
  filename: string;
  segments: Segment[];
  customHeaders?: Record<string, string>;
  decryptionKey?: string;
  decryptionIv?: string;
  outputPath?: string;
}

// Global state of download jobs
const downloadJobs: Map<string, DownloadJob> = new Map();

// Helper to calculate speed
const speedTrackers: Map<string, { lastBytes: number; lastTime: number }> = new Map();

// Helper to download a single file with custom headers and retry logic
async function fetchWithRetry(url: string, headers?: Record<string, string>, retries = 3): Promise<Response> {
  const mergedHeaders = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    ...headers,
  };

  for (let attempt = 1; attempt <= retries; attempt++) {
    try {
      const response = await fetch(url, { headers: mergedHeaders });
      if (!response.ok) {
        throw new Error(`Server returned status: ${response.status} ${response.statusText}`);
      }
      return response;
    } catch (error) {
      if (attempt === retries) {
        throw error;
      }
      // Wait before retrying (exponential backoff)
      await new Promise((resolve) => setTimeout(resolve, attempt * 1000));
    }
  }
  throw new Error('Failed to fetch after retries');
}

// Helper to resolve relative URLs
function resolveUrl(baseUrl: string, relativeUrl: string): string {
  try {
    return new URL(relativeUrl, baseUrl).toString();
  } catch {
    return relativeUrl;
  }
}

// Automatically extract embedded stream links from general web page content
function extractStreamsFromHtml(html: string, baseUrl: string): { url: string; type: 'm3u8' | 'mpd' | 'mp4'; label: string }[] {
  const streams: { url: string; type: 'm3u8' | 'mpd' | 'mp4'; label: string }[] = [];
  const uniqueUrls = new Set<string>();

  // Replace escaped backslashes which are extremely common in JSON data inside scripts
  const cleanedHtml = html.replace(/\\+/g, '');

  // 1. Regular expression matches for absolute m3u8, mpd, and mp4 URLs (double & single quotes)
  const absolutePatterns = [
    /(https?:\/\/[^\s"'`><]+?\.(?:m3u8|mpd|mp4)(?:[?#][^\s"'`<>]*)?)/gi
  ];

  for (const pattern of absolutePatterns) {
    let match;
    while ((match = pattern.exec(cleanedHtml)) !== null) {
      let rawUrl = match[1];
      // Clean up trailing characters or quotes if any escaped
      rawUrl = rawUrl.split('\\').join(''); // ensure no lingering backslashes
      try {
        const parsedUrl = new URL(rawUrl);
        const resolved = parsedUrl.toString();
        if (!uniqueUrls.has(resolved)) {
          uniqueUrls.add(resolved);
          let type: 'm3u8' | 'mpd' | 'mp4' = 'm3u8';
          if (resolved.includes('.mpd')) type = 'mpd';
          else if (resolved.includes('.mp4')) type = 'mp4';
          
          let label = `Extracted ${type.toUpperCase()} Stream`;
          if (resolved.includes('quality') || resolved.includes('resolution')) {
            label += ' (Dynamic Resolution)';
          }
          streams.push({ url: resolved, type, label });
        }
      } catch (e) {
        // invalid URL match, ignore
      }
    }
  }

  // 2. Relative path regexes for m3u8/mpd/mp4
  const relativePatterns = [
    /src=["']([^"']+\.(?:m3u8|mpd|mp4)(?:\?[^"']*)?)["']/gi,
    /href=["']([^"']+\.(?:m3u8|mpd|mp4)(?:\?[^"']*)?)["']/gi,
    /["']([^"'\s]+\.(?:m3u8|mpd|mp4)(?:\?[^"'\s]*)?)["']/gi
  ];

  for (const pattern of relativePatterns) {
    let match;
    while ((match = pattern.exec(cleanedHtml)) !== null) {
      const relPath = match[1];
      if (relPath.startsWith('http://') || relPath.startsWith('https://')) {
        continue; // handled by absolute matches
      }
      try {
        const resolved = resolveUrl(baseUrl, relPath);
        if (!uniqueUrls.has(resolved)) {
          uniqueUrls.add(resolved);
          let type: 'm3u8' | 'mpd' | 'mp4' = 'm3u8';
          if (resolved.includes('.mpd')) type = 'mpd';
          else if (resolved.includes('.mp4')) type = 'mp4';
          streams.push({
            url: resolved,
            type,
            label: `Page Embed (${type.toUpperCase()})`
          });
        }
      } catch (e) {
        // ignore
      }
    }
  }

  return streams;
}

// M3U8 Playlist Parser
function parseM3U8(content: string, baseUrl: string) {
  const lines = content.split('\n').map(line => line.trim());
  const isVariantPlaylist = content.includes('#EXT-X-STREAM-INF');

  if (isVariantPlaylist) {
    const variants: { resolution: string; bandwidth: number; url: string }[] = [];
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      if (line.startsWith('#EXT-X-STREAM-INF:')) {
        const bandwidthMatch = line.match(/BANDWIDTH=(\d+)/);
        const resolutionMatch = line.match(/RESOLUTION=(\d+x\d+)/);
        const bandwidth = bandwidthMatch ? parseInt(bandwidthMatch[1], 10) : 0;
        const resolution = resolutionMatch ? resolutionMatch[1] : 'Unknown';
        
        // Find next non-empty line
        let nextLine = '';
        for (let j = i + 1; j < lines.length; j++) {
          if (lines[j] && !lines[j].startsWith('#')) {
            nextLine = lines[j];
            break;
          }
        }
        if (nextLine) {
          variants.push({
            resolution,
            bandwidth,
            url: resolveUrl(baseUrl, nextLine),
          });
        }
      }
    }
    return { type: 'variant' as const, variants };
  } else {
    // Media playlist with actual segments
    const segments: string[] = [];
    let encryptionKeyInfo: { method: string; url: string; iv?: string } | null = null;

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      if (line.startsWith('#EXT-X-KEY:')) {
        const methodMatch = line.match(/METHOD=([^,\s]+)/);
        const uriMatch = line.match(/URI="([^"]+)"/);
        const ivMatch = line.match(/IV=0x([0-9a-fA-F]+)/);

        if (methodMatch && uriMatch) {
          encryptionKeyInfo = {
            method: methodMatch[1],
            url: resolveUrl(baseUrl, uriMatch[1]),
            iv: ivMatch ? ivMatch[1] : undefined,
          };
        }
      } else if (line.startsWith('#EXTINF:')) {
        // Find next non-empty line
        let nextLine = '';
        for (let j = i + 1; j < lines.length; j++) {
          if (lines[j] && !lines[j].startsWith('#')) {
            nextLine = lines[j];
            break;
          }
        }
        if (nextLine) {
          segments.push(resolveUrl(baseUrl, nextLine));
        }
      }
    }
    return { type: 'media' as const, segments, encryptionKeyInfo };
  }
}

// MPD Parser
function parseMPD(content: string, baseUrl: string) {
  // Simple regex-based parsing to extract representation variants and segments.
  const representationRegex = /<Representation\s+([^>]+)>/gi;
  const representations: { id: string; bandwidth: number; width?: number; height?: number; codecs?: string }[] = [];
  
  let match;
  while ((match = representationRegex.exec(content)) !== null) {
    const attrs = match[1];
    const idMatch = attrs.match(/id="([^"]+)"/);
    const bandwidthMatch = attrs.match(/bandwidth="([^"]+)"/);
    const widthMatch = attrs.match(/width="([^"]+)"/);
    const heightMatch = attrs.match(/height="([^"]+)"/);
    const codecsMatch = attrs.match(/codecs="([^"]+)"/);

    if (idMatch && bandwidthMatch) {
      representations.push({
        id: idMatch[1],
        bandwidth: parseInt(bandwidthMatch[1], 10),
        width: widthMatch ? parseInt(widthMatch[1], 10) : undefined,
        height: heightMatch ? parseInt(heightMatch[1], 10) : undefined,
        codecs: codecsMatch ? codecsMatch[1] : undefined,
      });
    }
  }

  // Segment template matching is very common in MPEG-DASH
  // We will support downloading basic DASH templates and segment lists
  const isSegmentTemplate = content.includes('<SegmentTemplate');
  
  return {
    type: 'mpd',
    variants: representations.map(r => ({
      resolution: r.width && r.height ? `${r.width}x${r.height}` : `Bandwidth: ${(r.bandwidth / 1000).toFixed(0)}kbps`,
      bandwidth: r.bandwidth,
      id: r.id,
      url: baseUrl, // Same base URL, representation ID is used to reconstruct segment paths
    })),
    isSegmentTemplate,
  };
}

// Decrypt buffer using AES-128-CBC
function decryptAes128(buffer: Buffer, key: Buffer, iv: Buffer): Buffer {
  const decipher = crypto.createDecipheriv('aes-128-cbc', key, iv);
  // Disable padding if needed or handle standard PKCS#7 padding
  decipher.setAutoPadding(true);
  return Buffer.concat([decipher.update(buffer), decipher.final()]);
}

// Download Worker Queue
async function runDownloader(jobId: string) {
  const job = downloadJobs.get(jobId);
  if (!job) return;

  const jobTempDir = path.resolve(TEMP_DIR, jobId);
  if (!fs.existsSync(jobTempDir)) {
    fs.mkdirSync(jobTempDir, { recursive: true });
  }

  job.status = 'downloading';
  downloadJobs.set(jobId, { ...job });

  let keyBuffer: Buffer | null = null;
  let defaultIv: Buffer | null = null;

  // Setup decryption if standard AES-128 key is available
  if (job.decryptionKey) {
    // Key could be a hex string or a raw string/URL
    if (job.decryptionKey.startsWith('0x') || /^[0-9a-fA-F]{32}$/.test(job.decryptionKey)) {
      const hex = job.decryptionKey.startsWith('0x') ? job.decryptionKey.slice(2) : job.decryptionKey;
      keyBuffer = Buffer.from(hex, 'hex');
    } else {
      keyBuffer = Buffer.from(job.decryptionKey, 'utf-8');
    }

    if (job.decryptionIv) {
      const hexIv = job.decryptionIv.startsWith('0x') ? job.decryptionIv.slice(2) : job.decryptionIv;
      defaultIv = Buffer.from(hexIv, 'hex');
    }
  }

  const concurrency = 5;
  let activeWorkers = 0;
  let currentSegmentIndex = 0;
  let totalBytesDownloaded = 0;

  speedTrackers.set(jobId, { lastBytes: 0, lastTime: Date.now() });

  // Status updating interval
  const speedInterval = setInterval(() => {
    const tracker = speedTrackers.get(jobId);
    const currentJob = downloadJobs.get(jobId);
    if (!tracker || !currentJob) return;

    const now = Date.now();
    const timeDiff = (now - tracker.lastTime) / 1000; // in seconds
    const bytesDiff = totalBytesDownloaded - tracker.lastBytes;

    if (timeDiff > 0.5) {
      const bytesPerSecond = bytesDiff / timeDiff;
      let speedStr = '0 B/s';
      if (bytesPerSecond >= 1024 * 1024) {
        speedStr = `${(bytesPerSecond / (1024 * 1024)).toFixed(1)} MB/s`;
      } else if (bytesPerSecond >= 1024) {
        speedStr = `${(bytesPerSecond / 1024).toFixed(1)} KB/s`;
      } else {
        speedStr = `${bytesPerSecond.toFixed(0)} B/s`;
      }

      currentJob.speed = speedStr;
      currentJob.activeWorkers = activeWorkers;
      currentJob.progress = Math.round((currentJob.downloadedSegments / currentJob.totalSegments) * 100);
      downloadJobs.set(jobId, { ...currentJob });

      speedTrackers.set(jobId, { lastBytes: totalBytesDownloaded, lastTime: now });
    }
  }, 1000);

  const worker = async () => {
    while (currentSegmentIndex < job.segments.length && downloadJobs.get(jobId)?.status === 'downloading') {
      const idx = currentSegmentIndex++;
      const segment = job.segments[idx];
      segment.status = 'downloading';
      activeWorkers++;
      downloadJobs.set(jobId, { ...job });

      const chunkPath = path.resolve(jobTempDir, `part_${idx}.ts`);

      try {
        const response = await fetchWithRetry(segment.url, job.customHeaders);
        const arrayBuffer = await response.arrayBuffer();
        let chunkBuffer = Buffer.from(arrayBuffer);

        // Perform Decryption if key is configured
        if (keyBuffer) {
          // If no custom IV, create standard IV from segment index (16 bytes big-endian)
          let segmentIv = defaultIv;
          if (!segmentIv) {
            segmentIv = Buffer.alloc(16);
            segmentIv.writeUInt32BE(idx, 12);
          }
          try {
            chunkBuffer = decryptAes128(chunkBuffer, keyBuffer, segmentIv);
          } catch (decryptErr) {
            console.error(`Decryption failed for segment ${idx}:`, decryptErr);
            throw new Error(`AES Decryption failed. Verify your Decryption Key.`);
          }
        }

        fs.writeFileSync(chunkPath, chunkBuffer);
        segment.status = 'completed';
        job.downloadedSegments++;
        totalBytesDownloaded += chunkBuffer.length;
      } catch (err: any) {
        console.error(`Failed to download segment ${idx}:`, err);
        segment.status = 'failed';
        job.status = 'failed';
        job.error = `Failed segment ${idx}: ${err.message}`;
        downloadJobs.set(jobId, { ...job });
        break;
      } finally {
        activeWorkers--;
        downloadJobs.set(jobId, { ...job });
      }
    }
  };

  // Launch parallel workers
  const workerPromises = Array.from({ length: Math.min(concurrency, job.segments.length) }, () => worker());
  await Promise.all(workerPromises);

  clearInterval(speedInterval);
  speedTrackers.delete(jobId);

  const finalJobState = downloadJobs.get(jobId);
  if (!finalJobState || finalJobState.status === 'failed') {
    return;
  }

  // Merging Phase
  finalJobState.status = 'merging';
  finalJobState.progress = 100;
  downloadJobs.set(jobId, { ...finalJobState });

  try {
    const finalFilePath = path.resolve(DOWNLOADS_DIR, finalJobState.filename);
    const writeStream = fs.createWriteStream(finalFilePath);

    for (let i = 0; i < finalJobState.segments.length; i++) {
      const chunkPath = path.resolve(jobTempDir, `part_${i}.ts`);
      if (fs.existsSync(chunkPath)) {
        const data = fs.readFileSync(chunkPath);
        writeStream.write(data);
        // Delete chunk right after writing to save disk space
        fs.unlinkSync(chunkPath);
      } else {
        throw new Error(`Missing segment chunk ${i} during merging.`);
      }
    }

    writeStream.end();

    // Clean up temporary job directory
    fs.rmdirSync(jobTempDir);

    finalJobState.status = 'completed';
    finalJobState.outputPath = finalFilePath;
    downloadJobs.set(jobId, { ...finalJobState });
  } catch (err: any) {
    console.error('Merging failed:', err);
    finalJobState.status = 'failed';
    finalJobState.error = `Merging failed: ${err.message}`;
    downloadJobs.set(jobId, { ...finalJobState });
  }
}

// --- API ENDPOINTS ---

// Check server status
app.get('/api/ping', (req, res) => {
  res.json({ status: 'ok', time: new Date().toISOString() });
});

// Fetch & Parse stream playlist metadata
app.post('/api/parse', async (req, res) => {
  const { url, headers } = req.body;

  if (!url) {
    return res.status(400).json({ error: 'URL is required' });
  }

  try {
    const isDirectStream = url.includes('.m3u8') || url.includes('.mpd') || url.includes('.mp4') || url.toLowerCase().endsWith('.mp4');

    // If it is not a direct stream link, we treat it as a video page and attempt automatic extraction!
    if (!isDirectStream) {
      try {
        const response = await fetchWithRetry(url, headers);
        const content = await response.text();

        // Check if the page itself returned raw HLS/DASH manifest signatures
        if (content.includes('#EXTM3U')) {
          const parsed = parseM3U8(content, url);
          return res.json({
            type: parsed.type === 'variant' ? 'm3u8-variant' : 'm3u8-media',
            variants: parsed.type === 'variant' ? parsed.variants : undefined,
            totalSegments: parsed.type === 'media' ? parsed.segments.length : undefined,
            encryption: parsed.type === 'media' ? parsed.encryptionKeyInfo : undefined,
          });
        } else if (content.includes('<MPD')) {
          const parsed = parseMPD(content, url);
          return res.json({
            type: 'mpd',
            variants: parsed.variants,
          });
        }

        // It is an HTML webpage, run the auto-extractor crawler
        const extracted = extractStreamsFromHtml(content, url);
        if (extracted && extracted.length > 0) {
          return res.json({
            type: 'extracted-webpage',
            extractedStreams: extracted,
          });
        } else {
          return res.status(404).json({
            error: 'No active stream link (m3u8, MPD, MP4) could be automatically extracted from this page. You may need to provide the direct stream URL from the browser developer network tools, or configure custom header cookies if the page requires authentication.',
          });
        }
      } catch (err: any) {
        return res.status(500).json({ error: `Failed to scrape page content: ${err.message}` });
      }
    }

    // Direct stream link parsing logic (original fallback)
    if (url.toLowerCase().endsWith('.mp4') || url.includes('.mp4?')) {
      return res.json({
        type: 'mp4',
        url,
        variants: [{ resolution: 'Source MP4', bandwidth: 0, url }],
      });
    }

    const response = await fetchWithRetry(url, headers);
    const content = await response.text();

    if (url.includes('.m3u8')) {
      const parsed = parseM3U8(content, url);
      if (parsed.type === 'variant') {
        return res.json({
          type: 'm3u8-variant',
          variants: parsed.variants,
        });
      } else {
        return res.json({
          type: 'm3u8-media',
          totalSegments: parsed.segments.length,
          encryption: parsed.encryptionKeyInfo,
          segmentsSample: parsed.segments.slice(0, 3),
        });
      }
    } else if (url.includes('.mpd')) {
      const parsed = parseMPD(content, url);
      return res.json({
        type: 'mpd',
        variants: parsed.variants,
        isSegmentTemplate: parsed.isSegmentTemplate,
      });
    } else {
      // Guess HLS or DASH by file signatures, default to custom parser or mp4
      if (content.includes('#EXTM3U')) {
        const parsed = parseM3U8(content, url);
        return res.json({
          type: parsed.type === 'variant' ? 'm3u8-variant' : 'm3u8-media',
          variants: parsed.type === 'variant' ? parsed.variants : undefined,
          totalSegments: parsed.type === 'media' ? parsed.segments.length : undefined,
          encryption: parsed.type === 'media' ? parsed.encryptionKeyInfo : undefined,
        });
      } else if (content.includes('<MPD')) {
        const parsed = parseMPD(content, url);
        return res.json({
          type: 'mpd',
          variants: parsed.variants,
        });
      } else {
        // Fallback to treat as a raw video stream or MP4
        return res.json({
          type: 'mp4',
          url,
          variants: [{ resolution: 'Direct Download / Stream', bandwidth: 0, url }],
        });
      }
    }
  } catch (err: any) {
    res.status(500).json({ error: `Failed to parse stream: ${err.message}` });
  }
});

// Trigger a download job
app.post('/api/download', async (req, res) => {
  const { url, type, selectedVariantUrl, headers, decryptionKey, decryptionIv, filename } = req.body;

  if (!url) {
    return res.status(400).json({ error: 'URL is required' });
  }

  const finalUrl = selectedVariantUrl || url;
  const targetFilename = filename ? (filename.endsWith('.mp4') ? filename : `${filename}.mp4`) : `download_${Date.now()}.mp4`;

  const jobId = crypto.randomBytes(8).toString('hex');

  const newJob: DownloadJob = {
    id: jobId,
    url: finalUrl,
    type: type || 'm3u8',
    status: 'pending',
    progress: 0,
    downloadedSegments: 0,
    totalSegments: 0,
    speed: '0 B/s',
    activeWorkers: 0,
    filename: targetFilename,
    segments: [],
    customHeaders: headers,
    decryptionKey,
    decryptionIv,
  };

  downloadJobs.set(jobId, newJob);

  // Run in background to prevent blocking HTTP response
  (async () => {
    try {
      if (newJob.type === 'mp4') {
        newJob.status = 'downloading';
        newJob.totalSegments = 1;
        downloadJobs.set(jobId, { ...newJob });

        // Direct single-file download
        const res = await fetchWithRetry(finalUrl, headers);
        const arrayBuffer = await res.arrayBuffer();
        const buffer = Buffer.from(arrayBuffer);

        const outPath = path.resolve(DOWNLOADS_DIR, targetFilename);
        fs.writeFileSync(outPath, buffer);

        newJob.progress = 100;
        newJob.downloadedSegments = 1;
        newJob.status = 'completed';
        newJob.outputPath = outPath;
        downloadJobs.set(jobId, { ...newJob });
      } else {
        // Fetch the manifest and parse segments
        const res = await fetchWithRetry(finalUrl, headers);
        const content = await res.text();

        let parsedSegments: string[] = [];
        let fetchedDecryptionKey = decryptionKey;
        let fetchedDecryptionIv = decryptionIv;

        if (newJob.type.startsWith('m3u8') || finalUrl.includes('.m3u8') || content.includes('#EXTM3U')) {
          const parsed = parseM3U8(content, finalUrl);
          if (parsed.type === 'media') {
            parsedSegments = parsed.segments;
            
            // Auto fetch HLS encryption key if available and none custom provided
            if (parsed.encryptionKeyInfo && parsed.encryptionKeyInfo.method === 'AES-128' && !decryptionKey) {
              try {
                const keyRes = await fetchWithRetry(parsed.encryptionKeyInfo.url, headers);
                const keyAB = await keyRes.arrayBuffer();
                fetchedDecryptionKey = Buffer.from(keyAB).toString('hex'); // Pass as hex
                if (parsed.encryptionKeyInfo.iv) {
                  fetchedDecryptionIv = parsed.encryptionKeyInfo.iv;
                }
              } catch (keyErr) {
                console.warn('Failed to auto-fetch HLS AES decryption key:', keyErr);
              }
            }
          } else {
            // Pick highest resolution variant if user didn't specify one
            const bestVariant = parsed.variants.reduce((prev, curr) => (curr.bandwidth > prev.bandwidth ? curr : prev), parsed.variants[0]);
            const childRes = await fetchWithRetry(bestVariant.url, headers);
            const childContent = await childRes.text();
            const childParsed = parseM3U8(childContent, bestVariant.url);
            if (childParsed.type === 'media') {
              parsedSegments = childParsed.segments;
              if (childParsed.encryptionKeyInfo && childParsed.encryptionKeyInfo.method === 'AES-128' && !decryptionKey) {
                try {
                  const keyRes = await fetchWithRetry(childParsed.encryptionKeyInfo.url, headers);
                  const keyAB = await keyRes.arrayBuffer();
                  fetchedDecryptionKey = Buffer.from(keyAB).toString('hex');
                  if (childParsed.encryptionKeyInfo.iv) {
                    fetchedDecryptionIv = childParsed.encryptionKeyInfo.iv;
                  }
                } catch (keyErr) {
                  console.warn('Failed to auto-fetch child HLS AES key:', keyErr);
                }
              }
            }
          }
        } else if (newJob.type === 'mpd' || finalUrl.includes('.mpd') || content.includes('<MPD')) {
          // DASH processing
          // Simple dash extractor: look for SegmentURL tags and pull media names
          const segmentUrls: string[] = [];
          
          // Reconstruct simple Dash media templates if found
          const templateMatch = content.match(/<SegmentTemplate[^>]*media="([^"]+)"[^>]*>/i);
          const initMatch = content.match(/<SegmentTemplate[^>]*initialization="([^"]+)"[^>]*>/i);
          const timescaleMatch = content.match(/<SegmentTemplate[^>]*timescale="([^"]+)"[^>]*>/i);
          const durationMatch = content.match(/<SegmentTemplate[^>]*duration="([^"]+)"[^>]*>/i);

          if (templateMatch && durationMatch) {
            const template = templateMatch[1];
            const duration = parseFloat(durationMatch[1]);
            const timescale = timescaleMatch ? parseFloat(timescaleMatch[1]) : 1;
            const segmentDuration = duration / timescale; // duration in seconds
            
            // Estimate total duration from MPD header e.g. mediaPresentationDuration="PT2H33M12S"
            const totalDurationMatch = content.match(/mediaPresentationDuration="PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+(?:\.\d+)?)S)?"/i);
            let totalSeconds = 600; // default to 10 mins if not parsed
            if (totalDurationMatch) {
              const h = totalDurationMatch[1] ? parseFloat(totalDurationMatch[1]) : 0;
              const m = totalDurationMatch[2] ? parseFloat(totalDurationMatch[2]) : 0;
              const s = totalDurationMatch[3] ? parseFloat(totalDurationMatch[3]) : 0;
              totalSeconds = h * 3600 + m * 60 + s;
            }

            const totalChunks = Math.ceil(totalSeconds / segmentDuration);
            const repIdMatch = content.match(/<Representation\s+id="([^"]+)"/i);
            const repId = repIdMatch ? repIdMatch[1] : '1';

            // First add initialization segment if it exists
            if (initMatch) {
              const initUrl = initMatch[1].replace('$RepresentationID$', repId);
              segmentUrls.push(resolveUrl(finalUrl, initUrl));
            }

            for (let i = 1; i <= totalChunks; i++) {
              let segUrl = template
                .replace('$RepresentationID$', repId)
                .replace('$Number$', i.toString());
              segmentUrls.push(resolveUrl(finalUrl, segUrl));
            }
          } else {
            // Find explicit segment URLs
            const segmentUrlRegex = /<SegmentURL\s+media="([^"]+)"/gi;
            let segMatch;
            while ((segMatch = segmentUrlRegex.exec(content)) !== null) {
              segmentUrls.push(resolveUrl(finalUrl, segMatch[1]));
            }
          }

          parsedSegments = segmentUrls;
        }

        if (parsedSegments.length === 0) {
          throw new Error('No segments found in the playlist. Confirm URL or check custom headers.');
        }

        newJob.segments = parsedSegments.map((sUrl, index) => ({
          url: sUrl,
          index,
          status: 'pending',
        }));
        newJob.totalSegments = parsedSegments.length;
        newJob.decryptionKey = fetchedDecryptionKey;
        newJob.decryptionIv = fetchedDecryptionIv;
        downloadJobs.set(jobId, { ...newJob });

        // Trigger Parallel Downloader
        await runDownloader(jobId);
      }
    } catch (err: any) {
      console.error(`Download execution failed:`, err);
      newJob.status = 'failed';
      newJob.error = err.message;
      downloadJobs.set(jobId, { ...newJob });
    }
  })();

  res.json({ jobId });
});

// Retrieve status of all jobs
app.get('/api/jobs', (req, res) => {
  const jobs = Array.from(downloadJobs.values()).map(job => ({
    id: job.id,
    url: job.url,
    type: job.type,
    status: job.status,
    progress: job.progress,
    downloadedSegments: job.downloadedSegments,
    totalSegments: job.totalSegments,
    speed: job.speed,
    filename: job.filename,
    error: job.error,
  }));
  res.json(jobs);
});

// Get detailed status of a specific job
app.get('/api/status/:id', (req, res) => {
  const job = downloadJobs.get(req.params.id);
  if (!job) {
    return res.status(404).json({ error: 'Job not found' });
  }
  res.json(job);
});

// Serve finished file for browser download
app.get('/api/download-file/:id', (req, res) => {
  const job = downloadJobs.get(req.params.id);
  if (!job) {
    return res.status(404).json({ error: 'Job not found' });
  }

  if (job.status !== 'completed' || !job.outputPath) {
    return res.status(400).json({ error: 'Download is not completed yet' });
  }

  if (!fs.existsSync(job.outputPath)) {
    return res.status(404).json({ error: 'File was deleted or not found on server' });
  }

  res.download(job.outputPath, job.filename);
});

// Cancel and cleanup a download job
app.post('/api/cancel/:id', (req, res) => {
  const job = downloadJobs.get(req.params.id);
  if (!job) {
    return res.status(404).json({ error: 'Job not found' });
  }

  if (job.status === 'downloading' || job.status === 'pending') {
    job.status = 'failed';
    job.error = 'Cancelled by user';
    downloadJobs.set(req.params.id, { ...job });

    // Clean up temporary chunks
    const jobTempDir = path.resolve(TEMP_DIR, job.id);
    if (fs.existsSync(jobTempDir)) {
      try {
        fs.rmSync(jobTempDir, { recursive: true, force: true });
      } catch (e) {
        console.warn('Failed to clean temp dir on cancel:', e);
      }
    }
    return res.json({ success: true, message: 'Job cancelled successfully' });
  }

  res.status(400).json({ error: 'Cannot cancel a completed or already failed job' });
});


// Serve React Frontend & Dev server middleware
const isProd = process.env.NODE_ENV === 'production';

if (!isProd) {
  const vite = await createViteServer({
    server: { middlewareMode: true },
    appType: 'spa',
  });
  app.use(vite.middlewares);
} else {
  app.use(express.static(path.resolve(__dirname, 'dist')));
  app.get('*', (req, res) => {
    res.sendFile(path.resolve(__dirname, 'dist/index.html'));
  });
}

const PORT = 3000;
app.listen(PORT, '0.0.0.0', () => {
  console.log(`[Server] StreamDownloader server running on port ${PORT} (isProd: ${isProd})`);
});
